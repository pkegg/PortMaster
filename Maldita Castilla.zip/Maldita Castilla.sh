#!/bin/bash

if [[ -e "/dev/input/by-path/platform-ff300000.usb-usb-0:1.2:1.0-event-joystick" ]]; then
  param_device="anbernic"
elif [[ -e "/dev/input/by-path/platform-odroidgo2-joypad-event-joystick" ]]; then
    if [[ ! -z $(cat /etc/emulationstation/es_input.cfg | grep "190000004b4800000010000001010000") ]]; then
	  param_device="oga"
	else
	  param_device="rk2020"
	fi
elif [[ -e "/dev/input/by-path/platform-odroidgo3-joypad-event-joystick" ]]; then
  param_device="ogs"
else
  param_device="chi"
fi

if [ -f "/opt/system/Advanced/Switch to main SD for Roms.sh" ]; then
  GAMEDIR="/roms2/ports/MalditaCastilla"
  LIBDIR="/roms2/ports/MalditaCastilla/lib32"
else
  GAMEDIR="/roms/ports/MalditaCastilla"
  LIBDIR="/roms/ports/MalditaCastilla/lib32"
fi

# gl4es
export LIBGL_FB=4

# system
export LD_LIBRARY_PATH=$LIBDIR:/usr/lib32:/usr/local/lib/arm-linux-gnueabihf/
export LD_PRELOAD=$LIBDIR/libbcm_host.so

cd $GAMEDIR

sudo ./rg351p-js2xbox.$param_device &
sudo ./oga_controls MalditaCastilla $param_device &
./MalditaCastilla 2>&1
sudo kill -9 $(pidof rg351p-js2xbox.$param_device)
sudo kill -9 $(pidof oga_controls)
sudo systemctl restart oga_events &
printf "\033c" >> /dev/tty1
