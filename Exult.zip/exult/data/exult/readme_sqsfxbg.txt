Ultima7 Black Gate for Exult SFX pack.

version 1.1

Here are the SFX (Sound Effects) for use with Exult Ultima7 Black Gate. 
These have been recorded directly from a Roland MT-32. This pack has 
been designed to replace the jmsfx.flx pack and goes in the DATA 
subdirectory. Just rename the <waves> entry under 
<config/disk/game/blackgate> in the exult.cfg file to sqsfxbg.flx.

Changes since 1.0: Moved sound for Grandfather clock.

Enjoy
Simon Quinn