Art assets in this plugin were developed by Freeverse Software for "Marathon 2: Durandal", released for Xbox Live Arcade. The content is copyright Bungie. Please contact Bungie before using these assets for any commercial purpose, or any purpose not directly connected with the Marathon community.

Additional art was created by Bruce Morrison and Steven Tse, in the style of their initial work for Freeverse. Special thanks go to them.

The Squarish Sans typeface was created by Tim Larson. See the readme file within the "squarishsans" directory for information.

Code in XBLA.lua is released under version 3 of the GNU General Public License. See the file "COPYING" for information.
