# lang_arabic
Arabic translation for nxengine-evo
