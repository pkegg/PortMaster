# DevilutionX
Diablo build for modern operating systems

Discord: https://discord.gg/aQBQdDe
GitHub: https://github.com/diasurgical/devilutionX

# How To Install:
 - Extract the files in the archive.
 - Install libsdl2 libsdl2-mixer libsdl2-ttf
 - Copy diabdat.mpq from your CD (or GoG install folder) to the DevilutionX install folder.
 - Run ./devilutionx

# Multiplayer
 - TCP/IP requires the host to expose port 6112.

All games are encrypted and password protected.

# Save Games and configurations
The configurations and save games are located in:
~/.local/share/diasurgical/devilution

# Credits
 - See list of contributors https://github.com/diasurgical/devilutionX/graphs/contributors

# Legal
This software is being released to the Public Domain. No assets of Diablo are being provided. You must own a copy of Diablo and have access to the assets beforehand in order to use this software.

Battle.net® - Copyright © 1996 Blizzard Entertainment, Inc. All rights reserved. Battle.net and Blizzard Entertainment are trademarks or registered trademarks of Blizzard Entertainment, Inc. in the U.S. and/or other countries.

Diablo® - Copyright © 1996 Blizzard Entertainment, Inc. All rights reserved. Diablo and Blizzard Entertainment are trademarks or registered trademarks of Blizzard Entertainment, Inc. in the U.S. and/or other countries.

This software is in no way associated with or endorsed by Blizzard Entertainment®.
